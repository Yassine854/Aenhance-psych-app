<template>
  <div class="p-6 space-y-6">
    <header class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
      <div>
        <h1 class="text-2xl font-semibold text-gray-900">Psychologists</h1>
      </div>
      <div class="flex items-center gap-3 w-full md:w-auto">
        <div class="flex items-center gap-2 flex-1">
          <select
            v-model="searchField"
            class="h-10 w-36 md:w-44 shrink-0 rounded-lg border-gray-300 bg-white px-3 text-sm text-gray-700"
            aria-label="Search filter"
          >
            <option value="id">ID</option>
            <option value="name">Name</option>
            <option value="email">Email</option>
            <option value="specialization">Specialization</option>
          </select>

          <div class="relative flex-1">
            <input v-model="searchQuery" type="text" :placeholder="searchPlaceholder" class="w-full rounded-lg border-gray-300 pl-10 pr-3 py-2"/>
            <button
              v-if="searchQuery"
              type="button"
              @click="clearSearch"
              class="absolute right-2 top-1/2 -translate-y-1/2 inline-flex items-center justify-center h-7 w-7 rounded-md text-gray-500 hover:bg-gray-100 hover:text-gray-700"
              aria-label="Clear text"
              title="Clear"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="h-4 w-4">
                <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd" />
              </svg>
            </button>
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M12.9 14.32a8 8 0 111.414-1.414l4.387 4.387a1 1 0 01-1.414 1.414l-4.387-4.387zM14 8a6 6 0 11-12 0 6 6 0 0112 0z" clip-rule="evenodd"/></svg>
          </div>
        </div>
        <button @click="openCreate()" type="button" title="New Psychologist" class="inline-flex items-center justify-center h-10 w-10 text-white rounded-lg shadow" :style="{ backgroundColor: createButtonColor }">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="h-5 w-5">
            <path fill-rule="evenodd" d="M12 2.25c.414 0 .75.336.75.75v8.25H21a.75.75 0 0 1 0 1.5h-8.25V21a.75.75 0 0 1-1.5 0v-8.25H3a.75.75 0 0 1 0-1.5h8.25V3c0-.414.336-.75.75-.75Z" clip-rule="evenodd" />
          </svg>
        </button>
      </div>
    </header>

      <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-4 py-3 text-left">
                  <button type="button" @click="toggleSort('id')" class="group inline-flex items-center gap-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700">
                    ID
                    <SortIcon :active="sortKey === 'id'" :dir="sortDir" />
                  </button>
                </th>
                <th class="px-4 py-3 text-left">
                  <button type="button" @click="toggleSort('name')" class="group inline-flex items-center gap-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700">
                    Name
                    <SortIcon :active="sortKey === 'name'" :dir="sortDir" />
                  </button>
                </th>
                <th class="px-4 py-3 text-left">
                  <button type="button" @click="toggleSort('specialization')" class="group inline-flex items-center gap-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700">
                    Specialization
                    <SortIcon :active="sortKey === 'specialization'" :dir="sortDir" />
                  </button>
                </th>
                <th class="px-4 py-3 text-left">
                  <button type="button" @click="toggleSort('price')" class="group inline-flex items-center gap-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700">
                    Price
                    <SortIcon :active="sortKey === 'price'" :dir="sortDir" />
                  </button>
                </th>
                <th class="px-4 py-3 text-left">
                  <button type="button" @click="toggleSort('approved')" class="group inline-flex items-center gap-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700">
                    Approved
                    <SortIcon :active="sortKey === 'approved'" :dir="sortDir" />
                  </button>
                </th>
                <th class="px-4 py-3 text-left">
                  <button type="button" @click="toggleSort('email')" class="group inline-flex items-center gap-1 text-xs font-medium text-gray-500 uppercase tracking-wider hover:text-gray-700">
                    Email
                    <SortIcon :active="sortKey === 'email'" :dir="sortDir" />
                  </button>
                </th>
                <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <tr v-if="(sorted || []).length === 0">
                <td colspan="7" class="px-4 py-6 text-sm text-gray-500 text-center">No psychologists found.</td>
              </tr>
              <tr v-for="p in sorted" :key="p.id" class="hover:bg-gray-50">
                <td class="px-4 py-3 text-sm text-gray-700">#{{ p.id }}</td>
                <td class="px-4 py-3">
                  <div class="flex items-center gap-3">
                    <img v-if="p.profile_image_url" :src="resolveStorageUrl(p.profile_image_url)" class="h-9 w-9 rounded-full object-cover" />
                    <div>
                      <div class="text-sm font-medium text-gray-900">{{ p.first_name }} {{ p.last_name }}</div>
                      <div class="text-xs text-gray-500">{{ p.gender || '-' }}</div>
                    </div>
                  </div>
                </td>
                <td class="px-4 py-3 text-xs text-gray-700">
                  <template v-if="(p.specialisations || []).length">
                    <div v-for="(line, idx) in specialisationsLines(p.specialisations)" :key="`${p.id}-sp-line-${idx}`" class="leading-5">
                      {{ line }}
                    </div>
                  </template>
                  <template v-else>-</template>
                </td>
                <td class="px-4 py-3 text-sm text-gray-700">{{ formatCurrency(p.price_per_session) }}</td>
                <td class="px-4 py-3">
                  <span :class="p.is_approved ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'" class="inline-flex items-center px-2 py-1 rounded text-xs font-medium">
                    {{ p.is_approved ? 'Approved' : 'Pending' }}
                  </span>
                </td>
                <td class="px-4 py-3 text-sm text-gray-700">
                  {{ p.user?.email || '-' }}
                </td>
                <td class="px-4 py-3 text-right">
                  <div class="inline-flex items-center gap-2">
                    <button
                      v-if="!p.is_approved"
                      type="button"
                      title="Approve"
                      @click="approveProfile(p)"
                      :disabled="approvingId === p.id"
                      class="inline-flex items-center justify-center h-9 w-9 rounded-lg border border-gray-200 bg-white text-[rgb(89,151,172)] hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="h-5 w-5">
                        <path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm13.61-1.814a.75.75 0 0 0-1.22-.872l-3.236 4.53-1.784-1.784a.75.75 0 1 0-1.06 1.06l2.4 2.4a.75.75 0 0 0 1.14-.094l3.76-5.24Z" clip-rule="evenodd" />
                      </svg>
                    </button>

                    <button
                      v-if="p.is_approved"
                      type="button"
                      title="Disapprove"
                      @click="disapproveProfile(p)"
                      :disabled="approvingId === p.id"
                      class="inline-flex items-center justify-center h-9 w-9 rounded-lg border border-gray-200 bg-white text-red-700 hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="h-5 w-5">
                        <path fill-rule="evenodd" d="M5.47 5.47a.75.75 0 011.06 0L12 10.94l5.47-5.47a.75.75 0 111.06 1.06L13.06 12l5.47 5.47a.75.75 0 11-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 010-1.06z" clip-rule="evenodd" />
                      </svg>
                    </button>

                    <button type="button" title="View" @click="openShow(p)" class="inline-flex items-center justify-center h-9 w-9 rounded-lg border border-gray-200 bg-white text-gray-700 hover:bg-gray-50">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="h-5 w-5">
                        <path d="M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z" />
                        <path fill-rule="evenodd" d="M12 3c5.392 0 9.878 3.88 10.818 9-.94 5.12-5.426 9-10.818 9S2.122 17.12 1.182 12C2.122 6.88 6.608 3 12 3Zm0 15a6 6 0 0 0 6-6 6 6 0 0 0-12 0 6 6 0 0 0 6 6Z" clip-rule="evenodd" />
                      </svg>
                    </button>

                    <button type="button" title="Edit" @click="openEdit(p)" class="inline-flex items-center justify-center h-9 w-9 rounded-lg border border-gray-200 bg-white text-gray-700 hover:bg-gray-50">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="h-5 w-5">
                        <path d="M21.44 11.05 13 19.5a4.5 4.5 0 0 1-1.591 1.06l-4.106 1.46a.75.75 0 0 1-.958-.958l1.46-4.106A4.5 4.5 0 0 1 8.866 15.5l8.44-8.44a2.25 2.25 0 0 1 3.182 0l.952.952a2.25 2.25 0 0 1 0 3.182Z" />
                        <path d="M13.5 7.5 16.5 10.5" />
                      </svg>
                    </button>

                    <button type="button" :title="p.user?.is_active ? 'Deactivate' : 'Activate'" @click="toggleActivation(p)" :disabled="activatingId === p.user?.id" :class="p.user?.is_active ? 'text-red-700 hover:bg-red-50' : 'text-green-700 hover:bg-green-50'" class="inline-flex items-center justify-center h-9 w-9 rounded-lg border border-gray-200 bg-white disabled:opacity-50 disabled:cursor-not-allowed">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="h-5 w-5">
                        <path fill-rule="evenodd" d="M12 2.25a.75.75 0 01.75.75v9a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM6.166 5.106a.75.75 0 010 1.06 8.25 8.25 0 1011.668 0 .75.75 0 011.06-1.06c3.808 3.807 3.808 9.98 0 13.788-3.807 3.808-9.98 3.808-13.788 0-3.808-3.807-3.808-9.98 0-13.788a.75.75 0 011.06 0z" clip-rule="evenodd" />
                      </svg>
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Pagination -->
        <div class="flex items-center justify-between px-4 py-3 border-t border-gray-200">
          <div class="text-sm text-gray-600">Showing {{ profiles.from }}-{{ profiles.to }} of {{ profiles.total }}</div>
          <div class="flex items-center gap-2">
            <Link
              v-for="(link, i) in profiles.links"
              :key="i"
              :href="link.url || '#'"
              :class="linkClasses(link)"
              :style="link.active ? { backgroundColor: brandColor, borderColor: brandColor, color: '#fff' } : null"
              preserve-scroll
            >
              <span v-html="link.label"></span>
            </Link>
          </div>
        </div>
      </div>

      <!-- Create Modal -->
      <Create :show="modal === 'create'" :specialisations="props.specialisations" :expertises="props.expertises" @close="closeModal" @created="handleCreated" />

      <!-- Show Modal -->
      <Show :show="modal === 'show'" :psychologist="selected" @close="closeModal" />

      <!-- Edit Modal -->
      <Edit :show="modal === 'edit'" :psychologist="selected" :specialisations="props.specialisations" :expertises="props.expertises" @close="closeModal" @saved="handleSaved" />
    </div>
</template>

<script setup>
import { Link, router } from '@inertiajs/vue3'
import { ref, computed, watch } from 'vue'
import AdminLayout from '@/Layouts/AdminLayout.vue'
import Edit from './Edit.vue'
import Create from './Create.vue'
import Show from './Show.vue'
import SortIcon from '@/Components/SortIcon.vue'
import { resolveStorageUrl } from '@/utils/storage'
import Swal from 'sweetalert2'

const props = defineProps({
  profiles: Object,
  filters: {
    type: Object,
    default: () => ({}),
  },
  specialisations: {
    type: Array,
    default: () => [],
  },
  expertises: {
    type: Array,
    default: () => [],
  },
})

const profilesData = ref(props.profiles?.data ? [...props.profiles.data] : [])
watch(
  () => props.profiles?.data,
  (next) => {
    profilesData.value = next ? [...next] : []
  }
)

const searchQuery = ref('')
const searchField = ref('id')
const isHydratingFilters = ref(false)
let searchDebounce = null

function normalizeFilters(filters = {}) {
  const validField = ['id', 'name', 'email', 'specialization'].includes(String(filters?.search_field || '').toLowerCase())
    ? String(filters.search_field).toLowerCase()
    : 'id'

  return {
    search_field: validField,
    search_query: String(filters?.search_query || filters?.q || ''),
  }
}

function hydrateFiltersFromProps() {
  const f = normalizeFilters(props.filters || {})
  isHydratingFilters.value = true
  searchField.value = f.search_field
  searchQuery.value = f.search_query
  isHydratingFilters.value = false
}

function currentQueryParams() {
  const params = {
    search_field: searchField.value,
    search_query: String(searchQuery.value || '').trim(),
  }

  return Object.fromEntries(
    Object.entries(params).filter(([_, value]) => value !== '' && value != null)
  )
}

function applyServerFilters({ resetPage = true } = {}) {
  if (isHydratingFilters.value) return

  const params = currentQueryParams()
  if (resetPage) params.page = 1

  router.get(route('psychologist-profiles.index'), params, {
    preserveScroll: true,
    preserveState: true,
    replace: true,
    only: ['profiles', 'filters'],
  })
}

function clearSearch() {
  if (searchDebounce) {
    clearTimeout(searchDebounce)
    searchDebounce = null
  }
  searchQuery.value = ''
  applyServerFilters({ resetPage: true })
}

hydrateFiltersFromProps()

watch(
  () => props.filters,
  () => {
    hydrateFiltersFromProps()
  }
)

watch(searchField, () => {
  if (isHydratingFilters.value) return
  applyServerFilters({ resetPage: true })
})

watch(searchQuery, () => {
  if (isHydratingFilters.value) return
  if (searchDebounce) clearTimeout(searchDebounce)
  searchDebounce = setTimeout(() => {
    applyServerFilters({ resetPage: true })
    searchDebounce = null
  }, 300)
})

const searchPlaceholder = computed(() => {
  switch (searchField.value) {
    case 'id':
      return 'Search by ID...'
    case 'name':
      return 'Search by name...'
    case 'email':
      return 'Search by email...'
    case 'specialization':
      return 'Search by specialization...'
    default:
      return 'Search...'
  }
})

const filtered = computed(() => (Array.isArray(profilesData.value) ? [...profilesData.value] : []))

// Sorting (client-side, applies after search)
const sortKey = ref('id')
const sortDir = ref('desc') // 'asc' | 'desc'

function toggleSort(key) {
  if (sortKey.value === key) {
    sortDir.value = sortDir.value === 'asc' ? 'desc' : 'asc'
    return
  }
  sortKey.value = key
  sortDir.value = 'desc'
}

const createButtonColor = 'rgb(175 81 102 / var(--tw-bg-opacity, 1))'

function getSortValue(p, key) {
  switch (key) {
    case 'id':
      return Number(p?.id || 0)
    case 'name':
      return `${p?.first_name || ''} ${p?.last_name || ''}`.trim().toLowerCase()
    case 'specialization':
      return String((p?.specialisations || []).map(s => s?.name).filter(Boolean).join(', ')).toLowerCase()
    case 'price':
      return Number(p?.price_per_session || 0)
    case 'approved':
      return p?.is_approved ? 1 : 0
    case 'email':
      return String(p?.user?.email || '').toLowerCase()
    default:
      return ''
  }
}

const sorted = computed(() => {
  const list = filtered.value || []
  const key = sortKey.value
  const dir = sortDir.value
  const multiplier = dir === 'asc' ? 1 : -1

  return list
    .map((item, idx) => ({ item, idx }))
    .sort((a, b) => {
      const av = getSortValue(a.item, key)
      const bv = getSortValue(b.item, key)

      if (typeof av === 'number' && typeof bv === 'number') {
        const diff = av - bv
        return diff !== 0 ? diff * multiplier : (a.idx - b.idx)
      }

      const diff = String(av).localeCompare(String(bv))
      return diff !== 0 ? diff * multiplier : (a.idx - b.idx)
    })
    .map(x => x.item)
})

function formatCurrency(value) {
  if (value == null) return '-'
  const n = Number(value)
  return new Intl.NumberFormat(undefined, { style: 'currency', currency: 'TND', minimumFractionDigits: 2 }).format(n)
}

function formatDate(value) {
  if (!value) return '-' 
  try { return new Date(value).toLocaleDateString() } catch { return '-' }
}

function specialisationsLines(items) {
  const names = (Array.isArray(items) ? items : [])
    .map((item) => String(item?.name || '').trim())
    .filter(Boolean)

  if (!names.length) return []

  const lines = []
  for (let i = 0; i < names.length; i += 3) {
    lines.push(names.slice(i, i + 3).join(', '))
  }
  return lines
}

const brandColor = 'rgb(89 151 172 / var(--tw-bg-opacity, 1))'

function linkClasses(link) {
  const base = 'inline-flex items-center justify-center px-3 py-1.5 rounded-lg text-sm border '
  if (link.active) return base + 'bg-indigo-600 text-white border-indigo-600'
  if (!link.url) return base + 'bg-gray-50 text-gray-400 border-gray-200 cursor-not-allowed'
  return base + 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
}

// Modals state
const modal = ref(null) // 'create' | 'show' | 'edit' | null
const selected = ref(null)

const approvingId = ref(null)
const activatingId = ref(null)

const toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 2500,
  timerProgressBar: true,
})

async function ensureCsrfToken() {
  const m1 = document.cookie.match(/XSRF-TOKEN=([^;]+)/)
  if (m1) return { token: decodeURIComponent(m1[1]), type: 'cookie' }

  const tokenEl = document.querySelector('meta[name="csrf-token"]')
  const metaToken = tokenEl?.getAttribute('content') || ''
  if (metaToken) return { token: metaToken, type: 'meta' }

  try {
    await fetch('/sanctum/csrf-cookie', { method: 'GET', credentials: 'include' })
  } catch {}

  const m2 = document.cookie.match(/XSRF-TOKEN=([^;]+)/)
  return m2 ? { token: decodeURIComponent(m2[1]), type: 'cookie' } : { token: '', type: 'none' }
}



function closeModal() {
  modal.value = null
  selected.value = null
}

async function openShow(p) {
  // Set basic selection immediately so UI can reflect it if needed
  selected.value = p

  // Try to fetch full verification details for this profile and merge them
  try {
    const url = route('psychologist.verification.admin.show', p.id, false)
    const res = await fetch(url, { credentials: 'include', headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' } })
    if (res.ok) {
      const data = await res.json()
      selected.value = { ...p, verification_details: data?.verification || null }
    }
  } catch (e) {
    // ignore network errors - we'll still open the modal with available data
    console.warn('Failed to fetch verification details', e)
  }

  modal.value = 'show'
}

function openEdit(p) {
  selected.value = p
  modal.value = 'edit'
}

function handleSaved(payload) {
  closeModal()
  if (payload?.type === 'account') {
    toast.fire({ icon: 'success', title: 'Account saved successfully.' })
  } else {
    toast.fire({ icon: 'success', title: 'Psychologist saved successfully.' })
  }

  if (payload?.profile?.id) {
    const idx = profilesData.value.findIndex(x => x?.id === payload.profile.id)
    if (idx !== -1) profilesData.value[idx] = payload.profile
  }

  if (payload?.user?.id) {
    const idx = profilesData.value.findIndex(x => x?.user?.id === payload.user.id)
    if (idx !== -1) {
      profilesData.value[idx] = {
        ...profilesData.value[idx],
        user: {
          ...(profilesData.value[idx].user || {}),
          ...payload.user,
        },
      }
    }
  }
}

function handleCreated(payload) {
  closeModal()
  toast.fire({ icon: 'success', title: 'Psychologist created successfully.' })

  const created = payload?.profile
  if (created?.id) {
    // Insert into current page list; sorting/search will re-derive view.
    profilesData.value = [created, ...profilesData.value]
  }
}

// Delete
async function confirmDelete(p) {
  const name = `${p?.first_name || ''} ${p?.last_name || ''}`.trim() || `#${p?.id ?? ''}`

  const result = await Swal.fire({
    title: 'Delete psychologist?'
    ,text: `You are about to delete ${name}. This action cannot be undone.`
    ,icon: 'warning'
    ,showCancelButton: true
    ,confirmButtonText: 'Yes, delete'
    ,cancelButtonText: 'Cancel'
    ,reverseButtons: true
    ,focusCancel: true
    ,confirmButtonColor: 'rgb(141,61,79)'
  })

  if (!result.isConfirmed) return

  try {
    const csrf = await ensureCsrfToken()
    const headers = {
      'X-Requested-With': 'XMLHttpRequest',
      'Accept': 'application/json',
    }

    if (csrf.type === 'meta' && csrf.token) {
      headers['X-CSRF-TOKEN'] = csrf.token
    } else if (csrf.type === 'cookie' && csrf.token) {
      headers['X-XSRF-TOKEN'] = csrf.token
    }

    const res = await fetch(route('psychologist-profiles.destroy', p.id), {
      method: 'DELETE',
      headers,
      credentials: 'same-origin',
    })

    if (!res.ok) {
      throw new Error('delete failed')
    }

    profilesData.value = profilesData.value.filter(x => x?.id !== p.id)

    Swal.fire({
      title: 'Deleted'
      ,text: 'Psychologist deleted successfully.'
      ,icon: 'success'
      ,timer: 1400
      ,showConfirmButton: false
    })
  } catch {
    Swal.fire({
      title: 'Delete failed'
      ,text: 'Could not delete this psychologist. Please try again.'
      ,icon: 'error'
    })
  }
}

async function approveProfile(p) {
  if (!p || p.is_approved) return

  const name = `${p?.first_name || ''} ${p?.last_name || ''}`.trim() || `#${p?.id ?? ''}`

  const result = await Swal.fire({
    title: 'Approve psychologist?'
    ,text: `Approve ${name} and mark this profile as approved?`
    ,icon: 'question'
    ,showCancelButton: true
    ,confirmButtonText: 'Yes, approve'
    ,cancelButtonText: 'Cancel'
    ,reverseButtons: true
    ,focusCancel: true
    ,confirmButtonColor: 'rgb(89,151,172)'
  })

  if (!result.isConfirmed) return

  approvingId.value = p.id
  try {
    const csrf = await ensureCsrfToken()
    const headers = {
      'X-Requested-With': 'XMLHttpRequest',
      'Accept': 'application/json',
    }

    if (csrf.type === 'meta' && csrf.token) {
      headers['X-CSRF-TOKEN'] = csrf.token
    } else if (csrf.type === 'cookie' && csrf.token) {
      headers['X-XSRF-TOKEN'] = csrf.token
    }

    const res = await fetch(route('psychologist-profiles.approve', p.id), {
      method: 'PATCH',
      headers,
      credentials: 'same-origin',
    })

    if (!res.ok) {
      await Swal.fire({
        title: 'Approve failed'
        ,text: 'Could not approve this psychologist. Please try again.'
        ,icon: 'error'
      })
      return
    }

    const idx = profilesData.value.findIndex(x => x?.id === p.id)
    if (idx !== -1) {
      profilesData.value[idx] = { ...profilesData.value[idx], is_approved: true }
    }

    Swal.fire({
      title: 'Approved'
      ,text: 'Psychologist approved successfully.'
      ,icon: 'success'
      ,timer: 1200
      ,showConfirmButton: false
    })
  } finally {
    approvingId.value = null
  }
}

async function disapproveProfile(p) {
  if (!p || !p.is_approved) return

  const name = `${p?.first_name || ''} ${p?.last_name || ''}`.trim() || `#${p?.id ?? ''}`

  const result = await Swal.fire({
    title: 'Disapprove psychologist?',
    text: `Disapprove ${name} and mark this profile as pending?`,
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'Yes, disapprove',
    cancelButtonText: 'Cancel',
    reverseButtons: true,
    focusCancel: true,
    confirmButtonColor: 'rgb(141,61,79)',
  })

  if (!result.isConfirmed) return

  approvingId.value = p.id
  try {
    const csrf = await ensureCsrfToken()
    const headers = {
      'X-Requested-With': 'XMLHttpRequest',
      'Accept': 'application/json',
    }

    if (csrf.type === 'meta' && csrf.token) {
      headers['X-CSRF-TOKEN'] = csrf.token
    } else if (csrf.type === 'cookie' && csrf.token) {
      headers['X-XSRF-TOKEN'] = csrf.token
    }

    const res = await fetch(route('psychologist-profiles.disapprove', p.id), {
      method: 'PATCH',
      headers,
      credentials: 'same-origin',
    })

    if (!res.ok) {
      await Swal.fire({
        title: 'Disapprove failed',
        text: 'Could not disapprove this psychologist. Please try again.',
        icon: 'error',
      })
      return
    }

    const idx = profilesData.value.findIndex(x => x?.id === p.id)
    if (idx !== -1) {
      profilesData.value[idx] = { ...profilesData.value[idx], is_approved: false }
    }

    Swal.fire({
      title: 'Disapproved',
      text: 'Psychologist disapproved successfully.',
      icon: 'success',
      timer: 1200,
      showConfirmButton: false,
    })
  } finally {
    approvingId.value = null
  }
}

async function toggleActivation(p) {
  if (!p?.user) return

  const name = `${p?.first_name || ''} ${p?.last_name || ''}`.trim() || `#${p?.id ?? ''}`
  const action = p.user.is_active ? 'deactivate' : 'activate'
  const actionText = p.user.is_active ? 'Deactivate' : 'Activate'

  const result = await Swal.fire({
    title: `${actionText} account?`,
    text: `Are you sure you want to ${action} the account for ${name}?`,
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: `Yes, ${action}`,
    cancelButtonText: 'Cancel',
    reverseButtons: true,
    focusCancel: true,
    confirmButtonColor: p.user.is_active ? 'rgb(141,61,79)' : 'rgb(89,151,172)',
  })

  if (!result.isConfirmed) return

  activatingId.value = p.user.id
  try {
    const csrf = await ensureCsrfToken()
    const headers = { 'X-Requested-With': 'XMLHttpRequest' }

    if (csrf.type === 'meta' && csrf.token) {
      headers['X-CSRF-TOKEN'] = csrf.token
    } else if (csrf.type === 'cookie' && csrf.token) {
      headers['X-XSRF-TOKEN'] = csrf.token
    }

    const url = p.user.is_active
      ? `/users/${p.user.id}/deactivate`
      : `/users/${p.user.id}/activate`

    const res = await fetch(url, {
      method: 'PATCH',
      headers,
      credentials: 'include',
    })

    if (!res.ok) {
      await Swal.fire({
        title: `${actionText} failed`,
        text: `Could not ${action} this account. Please try again.`,
        icon: 'error',
      })
      return
    }

    const idx = profilesData.value.findIndex(x => x?.user?.id === p.user.id)
    if (idx !== -1) {
      profilesData.value[idx] = {
        ...profilesData.value[idx],
        user: {
          ...profilesData.value[idx].user,
          is_active: !p.user.is_active,
        },
      }
    }

    Swal.fire({
      title: `${actionText}d`,
      text: `Account ${action}d successfully.`,
      icon: 'success',
      timer: 1200,
      showConfirmButton: false,
    })
  } finally {
    activatingId.value = null
  }
}

// Create modal
function openCreate() {
  modal.value = 'create'
}
</script>

<script>
export default {
  layout: AdminLayout,
  name: 'Admin/Psychologist/Index'
}
</script>

<style scoped>
/* Stylish scrollbar for modals */
.styled-scrollbar {
  /* Firefox */
  scrollbar-width: thin;
  scrollbar-color: rgb(89 151 172 / var(--tw-bg-opacity, 1)) rgba(229, 231, 235, 1);
}
.styled-scrollbar::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
.styled-scrollbar::-webkit-scrollbar-track {
  background: rgba(241, 245, 249, 1); /* slate-100 */
  border-radius: 9999px;
}
.styled-scrollbar::-webkit-scrollbar-thumb {
  background: rgb(89 151 172 / var(--tw-bg-opacity, 1));
  border-radius: 9999px;
  border: 2px solid #ffffff;
}
.styled-scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgb(89 151 172 / 0.85);
}
</style>
