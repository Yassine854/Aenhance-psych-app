ClickToPay Static Package

Files included at archive root:
- payment_en.html
- errors_en.html
- mobile_payment_en.html
- mobile_errors_en.html
- css/payment.css
- images/aenhance.svg

Manual requirements covered:
- XHTML Transitional doctype
- UTF-8 pages
- Required gateway scripts in payment and error pages
- Required form IDs and hidden fields
- Required input/select IDs: iPAN, iCVC, iTEXT, month, year
- Required blocks: orderNumber, amount, description, errorBlock, numberCountdown, infoBlock, indicator
- ACS form with MD, PaReq, TermUrl
- Visual validation classes .valid and .invalid
- Year dropdown starts at 2025

Upload steps:
1. Sign in to https://test.clictopay.com/mportal/#login.
2. Open Static > static upload and download.
3. Upload the ZIP archive generated from this folder contents, not the parent folder.
4. Test with https://test.clictopay.com/payment/merchants/<merchant_login>/test.html.

Notes:
- These pages are for the hosted ClickToPay customization flow, not for your Laravel public site.
- The gateway provides ../../js/* and ../../img/ajax-loader.gif at runtime.
- If your merchant account uses another language, duplicate the files with the corresponding locale suffix.